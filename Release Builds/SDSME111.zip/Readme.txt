Thanks for downloading this tool. I hope you'll have a nice hacking time with it


The games supported are Pok�mon Diamond, Pearl, Platinum, HeartGold and SoulSilver. All languages work.


Tool made by Spiky-Eared Pichu with the help of Arc
NSBMD viewer made by Kiwi.ds