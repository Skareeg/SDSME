Thanks for downloading this tool. I hope you'll have a nice hacking time with it


The games supported are Pok�mon Diamond, Pearl and Platinum. Pok�mon HeartGold and SoulSilver don't work yet, but compatibility is planned for the future.


Tool made by Spiky-Eared Pichu with the help of Arc
NSBMD viewer made by Kiwi.ds